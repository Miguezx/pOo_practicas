package entidadFinanciera.modelo;

public class Cuota extends Entidad {
    private int prestamoId;
    private double monto;

    public Cuota(int id, int prestamoId, double monto) {
        super(id);
        this.prestamoId = prestamoId;
        this.monto = monto;
    }

    public int getPrestamoId() {
        return prestamoId;
    }

    public void setPrestamoId(int prestamoId) {
        this.prestamoId = prestamoId;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public void calcular() {
        // Lógica para calcular la cuota
    }
}
