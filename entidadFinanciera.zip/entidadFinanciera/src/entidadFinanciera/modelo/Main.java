package entidadFinanciera.modelo;

public class Main {
    public static void main(String[] args) {
        Usuario usuario = new Usuario();
        usuario.ingresarInformacionUsuario();
        usuario.mostrarInformacionUsuario();
        usuario.solicitarPrestamo();
    }
}
