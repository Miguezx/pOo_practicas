package entidadFinanciera.modelo;

import java.util.Scanner;

public class Prestamo extends Entidad {
    private static final double MONTO_MAXIMO = 50000.0; // Monto máximo permitido
    private static final int PLAZO_MAXIMO = 60; // Plazo máximo en meses
    private double monto;
    private int plazo; // En meses
    private boolean aprobado;

    public Prestamo() {
        super();
        this.aprobado = false;
    }

    public Prestamo(int id, double monto, int plazo) {
        super(id);
        this.monto = monto;
        this.plazo = plazo;
        this.aprobado = false;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public int getPlazo() {
        return plazo;
    }

    public void setPlazo(int plazo) {
        this.plazo = plazo;
    }

    public void ingresarInformacionPrestamo(){
        super.leerInformacion(); //  Llama al método de la superclase para leer id
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el monto: ");
        this.setMonto(scanner.nextDouble());
        System.out.print("Ingrese el plazo (en meses): ");
        this.setPlazo(scanner.nextInt());
    }

    public void mostrarInformacionPrestamo(){
        String info = super.mostrarInformacion();
        info += "Monto: " + getMonto() + "\n" +
                "Plazo: " + getPlazo();
        System.out.println(info);
    }

    public void aprobar() {
        if (this.monto <= MONTO_MAXIMO && this.plazo <= PLAZO_MAXIMO) {
            this.aprobado = true;
            System.out.println("El préstamo ha sido aprobado.");
            } else {
                System.out.println("El préstamo no ha sido aprobado debido a que el monto o el plazo exceden los límites permitidos..");
            }
    }
}
